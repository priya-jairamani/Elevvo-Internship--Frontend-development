
function Pricing() {
  return (
    <div className="pricing-cards">
      <div className="pricing-card">
        <h3>Free</h3>
        <p>$0 / month</p>
      </div>
      <div className="pricing-card">
        <h3>Pro</h3>
        <p>$9 / month</p>
      </div>
      <div className="pricing-card">
        <h3>Team</h3>
        <p>$29 / month</p>
      </div>
    </div>
  );
}

export default Pricing;
