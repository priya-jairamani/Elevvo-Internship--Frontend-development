
function Testimonial() {
  return (
    <div className="testimonial-list">
      <blockquote>"TaskFlow changed the way I work!" – Sarah</blockquote>
      <blockquote>"Super easy and reliable." – James</blockquote>
      <blockquote>"My team loves it." – Priya</blockquote>
    </div>
  );
}

export default Testimonial;
