
function Footer() {
  return (
    <footer className="footer">
      <p>© 2025 TaskFlow. All rights reserved.</p>
      <div className="socials">
        <a href="#">🐦 Twitter</a>
        <a href="#">💼 LinkedIn</a>
        <a href="#">📘 Facebook</a>
      </div>
    </footer>
  );
}

export default Footer;
