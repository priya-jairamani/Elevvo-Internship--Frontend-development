
function Header() {
  return (
    <header className="header">
      <h1>TaskFlow</h1>
      <p>Organize your tasks. Simplify your life.</p>
      <button className="cta-btn">Get Started</button>
    </header>
  );
}

export default Header;
