import { useEffect, useState } from "react";
import "./App.css";

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [stats, setStats] = useState({ users: 0, uptime: 0, support: 0 });

  // Load theme from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "dark") {
      setDarkMode(true);
      document.body.classList.add("dark-mode");
    }
  }, []);

  // Animate stats
  useEffect(() => {
    let users = 0, uptime = 0, support = 0;
    const interval = setInterval(() => {
      if (users < 10000) users += 200;
      if (uptime < 99.9) uptime += 0.5;
      if (support < 24) support++;
      setStats({
        users: Math.min(users, 10000),
        uptime: Math.min(uptime, 99.9).toFixed(1),
        support: Math.min(support, 24),
      });
    }, 50);
    return () => clearInterval(interval);
  }, []);

  // Toggle theme
  const toggleTheme = () => {
    setDarkMode(!darkMode);
    if (!darkMode) {
      document.body.classList.add("dark-mode");
      localStorage.setItem("theme", "dark");
    } else {
      document.body.classList.remove("dark-mode");
      localStorage.setItem("theme", "light");
    }
  };

  return (
    <div>
      {/* Header */}
      <header className="header">
        <div className="logo-container">
          <h1 className="logo">TaskFlow</h1>
        </div>
        <p className="tagline">Manage tasks seamlessly with style ✨</p>
        <div className="header-actions">
  <button className="btn-outline">Get Started</button>
  <button
    className={`btn-outline theme-toggle ${darkMode ? "active" : ""}`}
    onClick={toggleTheme}
  >
    {darkMode ? "☀️ Light Mode" : "🌙 Dark Mode"}
  </button>
</div>
      </header>

      {/* Features Section */}
      <section className="section alt-bg">
        <h2 className="section-heading">Features</h2>
        <div className="grid">
          <div className="card fade-in">
            <h3 className="card-title">📋 Task Management</h3>
            <p>Create, edit, and organize your tasks with ease.</p>
          </div>
          <div className="card fade-in">
            <h3 className="card-title">⚡ Fast & Responsive</h3>
            <p>Optimized performance across all devices.</p>
          </div>
          <div className="card fade-in">
            <h3 className="card-title">🎨 Stylish UI</h3>
            <p>A modern design that makes productivity enjoyable.</p>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="section">
        <h2 className="section-heading">Pricing</h2>
        <div className="grid">
          <div className="card pricing-card">
            <h3>Basic</h3>
            <p className="price">$0</p>
            <ul>
              <li>Unlimited Tasks</li>
              <li>Basic Reminders</li>
            </ul>
            <button className="btn-secondary">Choose</button>
          </div>
          <div className="card pricing-card">
            <h3>Pro</h3>
            <p className="price">$5/mo</p>
            <ul>
              <li>Advanced Reminders</li>
              <li>Collaboration Tools</li>
              <li>Priority Support</li>
            </ul>
            <button className="btn-secondary">Choose</button>
          </div>
          <div className="card pricing-card">
            <h3>Enterprise</h3>
            <p className="price">Contact Us</p>
            <ul>
              <li>Custom Solutions</li>
              <li>Dedicated Manager</li>
            </ul>
            <button className="btn-secondary">Choose</button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="section stats">
        <h2 className="section-heading">Why Choose TaskFlow?</h2>
        <div className="grid">
          <div className="stat">
            <h3>{stats.users.toLocaleString()}+</h3>
            <p>Happy Users</p>
          </div>
          <div className="stat">
            <h3>{stats.uptime}%</h3>
            <p>Uptime</p>
          </div>
          <div className="stat">
            <h3>{stats.support}/7</h3>
            <p>Support</p>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="section alt-bg">
        <h2 className="section-heading">Frequently Asked Questions</h2>
        <div className="faq-list">
          <div className="faq-item">
            <h3>Is TaskFlow free to use?</h3>
            <p>Yes! You can use the free version with all basic features.</p>
          </div>
          <div className="faq-item">
            <h3>Can I use TaskFlow on mobile?</h3>
            <p>Absolutely, TaskFlow is fully responsive and mobile-friendly.</p>
          </div>
          <div className="faq-item">
            <h3>Is my data secure?</h3>
            <p>Yes, we use enterprise-level encryption for all stored data.</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <p>© 2025 TaskFlow. All rights reserved.</p>
        <p>
          <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a>
        </p>
      </footer>
    </div>
  );
}

export default App;
