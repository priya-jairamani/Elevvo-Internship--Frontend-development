const posts = [
  {
    title: "Latest Tech Trends 2025",
    category: "Tech",
    description: "Exploring AI, cloud, and futuristic gadgets.",
    date: "2025-09-01",
    image: "https://tse1.mm.bing.net/th/id/OIP.up5_i9wXYUoPhwx9CGle1gHaE8?pid=Api&h=220&P=0"
  },
  {
    title: "Journey to the Mountains",
    category: "Travel",
    description: "My amazing hiking experience in the Himalayas.",
    date: "2025-08-15",
     image: "https://tse1.mm.bing.net/th/id/OIP.dI22OgiQxCFyDNQ2PaNtvQHaE8?pid=Api&h=220&P=0"
  },
  {
    title: "Best Pasta Recipe",
    category: "Food",
    description: "Try this creamy pasta recipe for dinner tonight!",
    date: "2025-07-20",
    image: "https://tse1.mm.bing.net/th/id/OIP.vCcZCMcXk7T65H8J0xvaVAHaGj?pid=Api&h=220&P=0"
  },
  {
    title: "Tech Gadgets You Need",
    category: "Tech",
    description: "From smartwatches to VR headsets.",
    date: "2025-06-11",
    image: "https://tse2.mm.bing.net/th/id/OIP.4k7vcU8OLdBcfP5dYiuahgHaFN?pid=Api&h=220&P=0"
  },
  {
    title: "Exploring Paris",
    category: "Travel",
    description: "A guide to the most romantic city in the world.",
    date: "2025-05-02",
    image: "https://tse3.mm.bing.net/th/id/OIP.UxWwrNRuLzUm77dHNEXD7AHaEK?pid=Api&h=220&P=0"
  },
  {
    title: "Delicious Homemade Pizza",
    category: "Food",
    description: "Step by step to making the perfect pizza at home.",
    date: "2025-04-10",
    image: "https://tse4.mm.bing.net/th/id/OIP.eKRcna3P-uGZNTQWwxPNrwHaEK?pid=Api&h=220&P=0"
  }
];

const postsPerPage = 4;
let currentPage = 1;
let filteredPosts = posts;

function displayPosts() {
  const container = document.getElementById("postsContainer");
  container.innerHTML = "";

  const start = (currentPage - 1) * postsPerPage;
  const end = start + postsPerPage;
  const paginatedPosts = filteredPosts.slice(start, end);

  paginatedPosts.forEach(post => {
    const card = document.createElement("div");
    card.classList.add("card", post.category);

    card.innerHTML = `
      <img src="${post.image}" alt="${post.title}">
      <div class="content">
        <h3>${post.title}</h3>
        <p>${post.description}</p>
        <div class="date">${post.date}</div>
      </div>
    `;

    container.appendChild(card);
  });

  document.getElementById("pageIndicator").innerText = `Page ${currentPage} of ${Math.ceil(filteredPosts.length / postsPerPage)}`;
}

function filterPosts(category) {
  if (category === "all") {
    filteredPosts = posts;
  } else {
    filteredPosts = posts.filter(post => post.category === category);
  }
  currentPage = 1;
  displayPosts();
}

document.getElementById("searchInput").addEventListener("input", (e) => {
  const keyword = e.target.value.toLowerCase();
  filteredPosts = posts.filter(post => post.title.toLowerCase().includes(keyword));
  currentPage = 1;
  displayPosts();
});

document.getElementById("prevBtn").addEventListener("click", () => {
  if (currentPage > 1) {
    currentPage--;
    displayPosts();
  }
});
document.getElementById("nextBtn").addEventListener("click", () => {
  if (currentPage < Math.ceil(filteredPosts.length / postsPerPage)) {
    currentPage++;
    displayPosts();
  }
});

displayPosts();
