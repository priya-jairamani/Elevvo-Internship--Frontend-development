// Dark/Light Theme Toggle
const toggleBtn = document.getElementById("theme-toggle");
toggleBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
  toggleBtn.textContent = document.body.classList.contains("dark-mode") ? "☀️" : "🌙";
});

// Animate letters sequentially
window.addEventListener("DOMContentLoaded", () => {
  const letters = document.querySelectorAll(".brand-letter");
  letters.forEach((letter, index) => {
    setTimeout(() => { letter.classList.add("animate"); }, 700 + index * 200);
  });
});
